import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

export const getGeminiModel = (modelName: string = "gemini-3.1-pro-preview") => {
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set");
  }
  const ai = new GoogleGenAI({ apiKey });
  return ai;
};

export const analyzeResume = async (resumeText: string) => {
  const ai = getGeminiModel();
  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: `Analyze the following resume text. Identify skill gaps, suggest 3-5 specific courses or areas for improvement, and provide an overall employability score (0-100).
    
    Resume Text:
    ${resumeText}
    
    Format the response as JSON with the following structure:
    {
      "score": number,
      "summary": "string",
      "strengths": ["string"],
      "gaps": ["string"],
      "recommendations": [{"title": "string", "description": "string"}]
    }`,
    config: {
      responseMimeType: "application/json",
    },
  });

  return JSON.parse(response.text || "{}");
};

export const getCareerPath = async (currentSkills: string, targetRole: string) => {
  const ai = getGeminiModel();
  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: `Current Skills: ${currentSkills}
    Target Role: ${targetRole}
    
    Create a personalized upskilling roadmap for this career transition. Identify transferable strengths and recommended certifications.
    
    Format the response as JSON with the following structure:
    {
      "transferableStrengths": ["string"],
      "roadmap": [{"step": "string", "duration": "string", "details": "string"}],
      "certifications": ["string"]
    }`,
    config: {
      responseMimeType: "application/json",
    },
  });

  return JSON.parse(response.text || "{}");
};
