export interface ResumeAnalysis {
  score: number;
  summary: string;
  strengths: string[];
  gaps: string[];
  recommendations: { title: string; description: string }[];
}

export interface CareerRoadmap {
  transferableStrengths: string[];
  roadmap: { step: string; duration: string; details: string }[];
  certifications: string[];
}

export interface InterviewMessage {
  role: "user" | "assistant";
  content: string;
}

export interface InterviewFeedback {
  score: number;
  tone: string;
  confidence: string;
  accuracy: string;
  overallFeedback: string;
  improvementAreas: string[];
}
