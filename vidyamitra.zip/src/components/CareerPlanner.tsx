import { useState } from "react";
import { TrendingUp, Map, Award, Loader2, ArrowRight, Sparkles, BookOpen } from "lucide-react";
import { getCareerPath } from "../services/gemini";
import { CareerRoadmap } from "../types";
import { motion } from "motion/react";
import { cn } from "../lib/utils";

export default function CareerPlanner() {
  const [currentSkills, setCurrentSkills] = useState("");
  const [targetRole, setTargetRole] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [roadmap, setRoadmap] = useState<CareerRoadmap | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!currentSkills.trim() || !targetRole.trim()) return;

    setIsGenerating(true);
    setError(null);

    try {
      const result = await getCareerPath(currentSkills, targetRole);
      setRoadmap(result);
    } catch (err: any) {
      console.error(err);
      setError("An error occurred while generating your roadmap.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Upskilling Planner</h2>
        <p className="text-slate-500 mb-8">Map out your career transition with a personalized AI-driven learning path.</p>

        {!roadmap ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Current Skills & Experience</label>
                <textarea 
                  value={currentSkills}
                  onChange={(e) => setCurrentSkills(e.target.value)}
                  placeholder="e.g. Python, SQL, Project Management, 2 years in Marketing..."
                  className="w-full h-32 bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Target Career Role</label>
                <input 
                  type="text"
                  value={targetRole}
                  onChange={(e) => setTargetRole(e.target.value)}
                  placeholder="e.g. Data Scientist, Cloud Architect..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                />
              </div>
              <button 
                onClick={handleGenerate}
                disabled={isGenerating || !currentSkills.trim() || !targetRole.trim()}
                className="w-full py-4 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isGenerating ? (
                  <>
                    <Loader2 size={20} className="animate-spin" />
                    Generating Roadmap...
                  </>
                ) : (
                  <>
                    <Sparkles size={20} />
                    Generate My Roadmap
                  </>
                )}
              </button>
              {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}
            </div>
            <div className="bg-emerald-50 rounded-3xl p-8 flex flex-col items-center justify-center text-center border border-emerald-100">
              <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-emerald-100 flex items-center justify-center text-emerald-600 mb-6">
                <TrendingUp size={32} />
              </div>
              <h3 className="text-xl font-bold text-emerald-900 mb-4">Why use the Career Planner?</h3>
              <ul className="space-y-4 text-sm text-emerald-800 text-left">
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 bg-emerald-200 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle size={12} className="text-emerald-700" />
                  </div>
                  <span>Identify transferable strengths you already possess.</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 bg-emerald-200 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle size={12} className="text-emerald-700" />
                  </div>
                  <span>Get a step-by-step timeline for your transition.</span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-5 h-5 bg-emerald-200 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle size={12} className="text-emerald-700" />
                  </div>
                  <span>Discover industry-recognized certifications.</span>
                </li>
              </ul>
            </div>
          </div>
        ) : (
          <div className="space-y-12">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
                  <Map size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">Your Career Roadmap</h3>
                  <p className="text-slate-500">Transitioning from your current role to <span className="text-emerald-600 font-bold">{targetRole}</span></p>
                </div>
              </div>
              <button 
                onClick={() => setRoadmap(null)}
                className="text-sm font-semibold text-emerald-600 hover:underline"
              >
                Create New Plan
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-8">
                <div className="space-y-6">
                  <h4 className="font-bold text-slate-900 flex items-center gap-2">
                    <BookOpen size={20} className="text-emerald-600" />
                    Step-by-Step Roadmap
                  </h4>
                  <div className="space-y-6 relative before:absolute before:left-[19px] before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-100">
                    {roadmap.roadmap.map((step, i) => (
                      <div key={i} className="relative pl-12">
                        <div className="absolute left-0 top-0 w-10 h-10 bg-white border-2 border-emerald-500 rounded-full flex items-center justify-center text-emerald-600 font-bold text-sm z-10 shadow-sm">
                          {i + 1}
                        </div>
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:border-emerald-300 transition-colors">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-bold text-slate-900">{step.step}</h5>
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full uppercase tracking-widest">
                              {step.duration}
                            </span>
                          </div>
                          <p className="text-slate-500 text-sm leading-relaxed">{step.details}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-8">
                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                  <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <Sparkles size={18} className="text-emerald-600" />
                    Transferable Strengths
                  </h4>
                  <div className="space-y-3">
                    {roadmap.transferableStrengths.map((strength, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 text-sm text-slate-700 font-medium">
                        <ArrowRight size={14} className="text-emerald-500" />
                        {strength}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-emerald-900 p-6 rounded-3xl text-white shadow-xl shadow-emerald-100">
                  <h4 className="font-bold mb-4 flex items-center gap-2">
                    <Award size={18} className="text-emerald-400" />
                    Top Certifications
                  </h4>
                  <div className="space-y-4">
                    {roadmap.certifications.map((cert, i) => (
                      <div key={i} className="p-4 bg-white/10 rounded-2xl border border-white/10 hover:bg-white/20 transition-colors">
                        <p className="text-sm font-bold">{cert}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function CheckCircle({ size, className }: { size: number; className?: string }) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}
