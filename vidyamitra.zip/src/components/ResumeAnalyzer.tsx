import { useState, useRef } from "react";
import { Upload, FileText, CheckCircle2, AlertCircle, Loader2, BarChart3 } from "lucide-react";
import * as pdfjs from "pdfjs-dist";
import { analyzeResume } from "../services/gemini";
import { ResumeAnalysis } from "../types";
import { motion } from "motion/react";
import { cn } from "../lib/utils";

// Set worker source for pdfjs
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

export default function ResumeAnalyzer() {
  const [file, setFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<ResumeAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const extractTextFromPdf = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise;
    let fullText = "";
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(" ");
      fullText += pageText + "\n";
    }
    
    return fullText;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === "application/pdf") {
      setFile(selectedFile);
      setError(null);
    } else {
      setError("Please upload a valid PDF file.");
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    setIsAnalyzing(true);
    setError(null);

    try {
      const text = await extractTextFromPdf(file);
      if (!text.trim()) {
        throw new Error("Could not extract text from PDF. The file might be empty or scanned.");
      }
      const result = await analyzeResume(text);
      setAnalysis(result);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An error occurred during analysis.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Resume Evaluation</h2>
        <p className="text-slate-500 mb-8">Upload your resume in PDF format for an AI-powered skill gap analysis.</p>

        {!analysis ? (
          <div 
            className={cn(
              "border-2 border-dashed rounded-3xl p-12 flex flex-col items-center justify-center transition-all duration-300",
              file ? "border-indigo-300 bg-indigo-50/30" : "border-slate-200 hover:border-indigo-300 hover:bg-slate-50"
            )}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              const droppedFile = e.dataTransfer.files[0];
              if (droppedFile?.type === "application/pdf") {
                setFile(droppedFile);
                setError(null);
              }
            }}
          >
            <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center text-indigo-600 mb-4">
              <Upload size={32} />
            </div>
            <p className="text-lg font-semibold text-slate-900 mb-1">
              {file ? file.name : "Click or drag to upload resume"}
            </p>
            <p className="text-slate-500 text-sm mb-6">PDF files only (max 5MB)</p>
            
            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".pdf"
              className="hidden"
            />
            
            <div className="flex gap-3">
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="px-6 py-2.5 bg-white border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-all"
              >
                Select File
              </button>
              {file && (
                <button 
                  onClick={handleUpload}
                  disabled={isAnalyzing}
                  className="px-6 py-2.5 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center gap-2"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 size={18} className="animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    "Analyze Now"
                  )}
                </button>
              )}
            </div>
            
            {error && (
              <div className="mt-6 flex items-center gap-2 text-red-600 bg-red-50 px-4 py-2 rounded-lg text-sm font-medium">
                <AlertCircle size={16} />
                {error}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">Analysis Complete</h3>
                  <p className="text-slate-500">We've identified your strengths and areas for growth.</p>
                </div>
              </div>
              <button 
                onClick={() => {
                  setAnalysis(null);
                  setFile(null);
                }}
                className="text-sm font-semibold text-indigo-600 hover:underline"
              >
                Upload Another
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 flex flex-col items-center justify-center text-center">
                <div className="text-4xl font-black text-indigo-600 mb-2">{analysis.score}%</div>
                <div className="text-sm font-bold text-slate-500 uppercase tracking-wider">Employability Score</div>
              </div>
              <div className="md:col-span-2 bg-indigo-600 p-6 rounded-2xl text-white">
                <h4 className="font-bold mb-2 flex items-center gap-2">
                  <BarChart3 size={18} />
                  Professional Summary
                </h4>
                <p className="text-indigo-50 text-sm leading-relaxed">
                  {analysis.summary}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h4 className="font-bold text-slate-900 flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  Key Strengths
                </h4>
                <div className="flex flex-wrap gap-2">
                  {analysis.strengths.map((s, i) => (
                    <span key={i} className="px-3 py-1 bg-green-50 text-green-700 rounded-full text-xs font-semibold border border-green-100">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h4 className="font-bold text-slate-900 flex items-center gap-2">
                  <div className="w-2 h-2 bg-amber-500 rounded-full" />
                  Skill Gaps Identified
                </h4>
                <div className="flex flex-wrap gap-2">
                  {analysis.gaps.map((g, i) => (
                    <span key={i} className="px-3 py-1 bg-amber-50 text-amber-700 rounded-full text-xs font-semibold border border-amber-100">
                      {g}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-bold text-slate-900">Recommended Courses & Actions</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {analysis.recommendations.map((rec, i) => (
                  <div key={i} className="p-4 bg-white border border-slate-200 rounded-2xl hover:border-indigo-300 transition-colors">
                    <h5 className="font-bold text-slate-900 mb-1">{rec.title}</h5>
                    <p className="text-slate-500 text-xs leading-relaxed">{rec.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
