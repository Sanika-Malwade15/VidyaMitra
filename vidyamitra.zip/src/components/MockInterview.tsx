import { useState, useEffect, useRef } from "react";
import { Send, User, Bot, Loader2, RefreshCw, Award, Target, Zap } from "lucide-react";
import { getGeminiModel } from "../services/gemini";
import { InterviewMessage, InterviewFeedback } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../lib/utils";

export default function MockInterview() {
  const [messages, setMessages] = useState<InterviewMessage[]>([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isInterviewing, setIsInterviewing] = useState(false);
  const [feedback, setFeedback] = useState<InterviewFeedback | null>(null);
  const [isGeneratingFeedback, setIsGeneratingFeedback] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const startInterview = async () => {
    setIsInterviewing(true);
    setMessages([]);
    setFeedback(null);
    setIsTyping(true);

    try {
      const ai = getGeminiModel();
      const chat = ai.chats.create({
        model: "gemini-3.1-pro-preview",
        config: {
          systemInstruction: "You are an expert interviewer for a top-tier tech company. Your goal is to conduct a realistic mock interview. Start by asking the candidate to introduce themselves and specify the role they are applying for. Ask one question at a time, wait for their response, and then follow up or move to the next question. Be professional, slightly challenging, but supportive.",
        },
      });

      // Save chat instance to a ref if needed, but for now we'll just send the first message
      const response = await chat.sendMessage({ message: "Hello, I'm ready to start my mock interview." });
      setMessages([{ role: "assistant", content: response.text || "Hello! I'm your interviewer today. To get started, could you please introduce yourself and tell me which role you're applying for?" }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMessage = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setIsTyping(true);

    try {
      const ai = getGeminiModel();
      const history = messages.map(m => ({
        role: m.role === "user" ? "user" : "model",
        parts: [{ text: m.content }]
      }));

      const chat = ai.chats.create({
        model: "gemini-3.1-pro-preview",
        config: {
          systemInstruction: "You are an expert interviewer. Continue the interview based on the candidate's responses. Ask one question at a time. If the candidate has answered 5-6 questions, you can conclude the interview and tell them to click the 'Generate Feedback' button.",
        },
        history: history as any
      });

      const response = await chat.sendMessage({ message: userMessage });
      setMessages(prev => [...prev, { role: "assistant", content: response.text || "I see. Let's move on to the next question." }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  const generateFeedback = async () => {
    setIsGeneratingFeedback(true);
    try {
      const ai = getGeminiModel();
      const interviewTranscript = messages.map(m => `${m.role.toUpperCase()}: ${m.content}`).join("\n\n");
      
      const response = await ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: `Analyze the following mock interview transcript and provide detailed feedback. Evaluate tone, confidence, and accuracy.
        
        Transcript:
        ${interviewTranscript}
        
        Format the response as JSON with the following structure:
        {
          "score": number,
          "tone": "string",
          "confidence": "string",
          "accuracy": "string",
          "overallFeedback": "string",
          "improvementAreas": ["string"]
        }`,
        config: {
          responseMimeType: "application/json",
        },
      });

      setFeedback(JSON.parse(response.text || "{}"));
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingFeedback(false);
    }
  };

  return (
    <div className="space-y-8">
      {!isInterviewing ? (
        <div className="bg-white p-12 rounded-3xl border border-slate-200 shadow-sm text-center">
          <div className="w-20 h-20 bg-purple-100 text-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-50">
            <Bot size={40} />
          </div>
          <h2 className="text-3xl font-bold text-slate-900 mb-4">AI Interview Simulator</h2>
          <p className="text-slate-500 max-w-xl mx-auto mb-8">
            Experience a realistic interview environment. Our AI will ask you role-specific questions and provide detailed feedback on your communication and technical accuracy.
          </p>
          <button 
            onClick={startInterview}
            className="px-8 py-4 bg-purple-600 text-white font-bold rounded-2xl hover:bg-purple-700 transition-all shadow-lg shadow-purple-200 flex items-center gap-2 mx-auto"
          >
            <Zap size={20} />
            Start Mock Interview
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[700px]">
          {/* Chat Area */}
          <div className="lg:col-span-2 flex flex-col bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center text-white">
                  <Bot size={20} />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-sm">AI Interviewer</p>
                  <p className="text-[10px] text-green-500 font-bold uppercase tracking-widest">Live Session</p>
                </div>
              </div>
              <button 
                onClick={() => {
                  setIsInterviewing(false);
                  setMessages([]);
                  setFeedback(null);
                }}
                className="text-xs font-bold text-slate-400 hover:text-red-500 transition-colors"
              >
                End Session
              </button>
            </div>

            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth"
            >
              {messages.map((m, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex gap-4 max-w-[85%]",
                    m.role === "user" ? "ml-auto flex-row-reverse" : ""
                  )}
                >
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center shrink-0",
                    m.role === "user" ? "bg-indigo-100 text-indigo-600" : "bg-purple-100 text-purple-600"
                  )}>
                    {m.role === "user" ? <User size={16} /> : <Bot size={16} />}
                  </div>
                  <div className={cn(
                    "p-4 rounded-2xl text-sm leading-relaxed",
                    m.role === "user" 
                      ? "bg-indigo-600 text-white rounded-tr-none" 
                      : "bg-slate-100 text-slate-800 rounded-tl-none"
                  )}>
                    {m.content}
                  </div>
                </motion.div>
              ))}
              {isTyping && (
                <div className="flex gap-4">
                  <div className="w-8 h-8 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center">
                    <Bot size={16} />
                  </div>
                  <div className="bg-slate-100 p-4 rounded-2xl rounded-tl-none flex gap-1">
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" />
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-100">
              <div className="flex gap-2">
                <input 
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder="Type your response..."
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
                />
                <button 
                  onClick={handleSend}
                  disabled={isTyping || !input.trim()}
                  className="w-12 h-12 bg-purple-600 text-white rounded-xl flex items-center justify-center hover:bg-purple-700 transition-all disabled:opacity-50"
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </div>

          {/* Feedback Area */}
          <div className="flex flex-col gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex-1 overflow-y-auto">
              <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
                <Award size={20} className="text-purple-600" />
                Performance Feedback
              </h3>
              
              {!feedback ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-4">
                  <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 mb-4">
                    <Target size={32} />
                  </div>
                  <p className="text-slate-500 text-sm mb-6">Complete at least 5 questions to generate your performance report.</p>
                  <button 
                    onClick={generateFeedback}
                    disabled={isGeneratingFeedback || messages.length < 4}
                    className="w-full py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isGeneratingFeedback ? (
                      <>
                        <Loader2 size={18} className="animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      "Generate Report"
                    )}
                  </button>
                </div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between p-4 bg-purple-50 rounded-2xl border border-purple-100">
                    <div>
                      <p className="text-[10px] font-bold text-purple-600 uppercase tracking-widest">Overall Score</p>
                      <p className="text-3xl font-black text-purple-900">{feedback.score}/100</p>
                    </div>
                    <button 
                      onClick={() => setFeedback(null)}
                      className="p-2 text-purple-400 hover:text-purple-600"
                    >
                      <RefreshCw size={18} />
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Tone & Communication</p>
                      <p className="text-sm text-slate-700">{feedback.tone}</p>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Confidence Level</p>
                      <p className="text-sm text-slate-700">{feedback.confidence}</p>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Technical Accuracy</p>
                      <p className="text-sm text-slate-700">{feedback.accuracy}</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <p className="text-sm font-bold text-slate-900">Areas for Improvement</p>
                    <ul className="space-y-2">
                      {feedback.improvementAreas.map((area, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs text-slate-600">
                          <div className="w-1.5 h-1.5 bg-red-400 rounded-full mt-1 shrink-0" />
                          {area}
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
